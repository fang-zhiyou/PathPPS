# The source code of GTK and PathGES

Our experiments assume prior installation of Python 3 via the `python3` command.
First clone the repository. A list of dependancies can be found in ``requirements.txt``. 

### PathGES
To run the experiments for PathGES, run the following commmand from the root directory of the repository. Our experiments can be carried out using the following datasets: `Chicago`, `beijing`, `feicheng`.

```
python benchmark.py DATA SETUP-FlAG NUM-QUERIES NUM-CORES
```

where DATA specifies the graph dataset to encrypt, SETUP-FlAG specifies whether to run setup-up experiments (0 = don't run setup experiments), and NUM-QUERIES and NUM-CORES are integers specifying the number of queries to test and the number of cores to use, respectively. Note that setup must be run before running query experiments at least once for each dataset, in order to encrypt the graph. Once the graph is encrypted the query experiments may be run without setup.


### GTK
Then run the command
```
python benchmark-gkt.py DATA NUM-QUERIES NUM-CORES
```
where DATA, NUM-QUERIES, and NUM-CORES are specified as before.



### Results
To clean the data obtained by running PathGES and calculate the averages partitioned by path lengths (as found in our paper), run the following additional command:
```
python clean-data.py DATA
```
where DATA, once again, specifies the reuslts from the corresponding dataset DATA to be cleaned.

Similarly, clean the data obtained by running GKT and calculate the averages partitioned by path lengths (as found in our paper) run the following:
```
python3 clean-data-gkt.py DATA
```