import random
import time

class Direct:
    def __init__(self, n):
        self.n = n
        self.side = 2 ** n

    def d2xy_v(self, d: int):
        x = d // self.side
        y = d % self.side
        if x % 2 == 1:
            y = self.side - y - 1
        return x, y

    def d2xy_h(self, d: int):
        x = d // self.side
        y = d % self.side
        if x % 2 == 1:
            y = self.side - y - 1
        return y, self.side - 1 - x

    def xy2d_v(self, x, y):
        d = x * self.side
        if x % 2 == 1:
            d += self.side - y - 1
        else:
            d += y
        return d

    def xy2d_h(self, x, y):
        x, y = self.side - 1 - y, x
        d = x * self.side
        if x % 2 == 1:
            d += self.side - y - 1
        else:
            d += y
        return d

class Hilbert:
    def __init__(self, order):
        self.n = order
        self.side = 2 ** order

    def d2xy_down(self, d: int):
        return self.fast_d2xy(d)

    def xy2d_down(self, x: int, y: int):
        return self.fast_xy2d(x, y)

    def d2xy_left(self, d: int):
        x, y = self.fast_d2xy(d)
        return y, self.side - 1 - x

    def xy2d_left(self, x: int, y: int):
        x, y = self.side - 1 - y, x
        return self.fast_xy2d(x, y)

    def d2xy_up(self, d: int):
        x, y = self.fast_d2xy(d)
        return self.side - 1 - x, self.side - 1 - y

    def xy2d_up(self, x: int, y: int):
        x, y = self.side - 1 - x, self.side - 1 - y
        return self.fast_xy2d(x, y)

    def d2xy_right(self, d: int):
        x, y = self.fast_d2xy(d)
        return self.side - 1 - y, x


    def xy2d_right(self, x: int, y: int):
        x, y = y, self.side - 1 - x
        return self.fast_xy2d(x, y)

    def fast_d2xy(self, d):
        """将一维 Hilbert 索引 d 转换为二维坐标 (x, y)。"""
        x = y = 0
        t = d
        s = 1
        while s < (1 << self.n):  # 循环直到 s 达到 2^n
            rx = 1 & (t // 2)
            ry = 1 & (t ^ rx)
            if ry == 0:
                if rx == 1:
                    x, y = s - 1 - x, s - 1 - y
                # 交换 x 和 y
                x, y = y, x
            x += s * rx
            y += s * ry
            t //= 4
            s *= 2
        return x, y

    def fast_xy2d(self, x, y):
        """将二维坐标 (x, y) 转换为 Hilbert 曲线上的一维索引 d。"""
        d = 0
        s = 1 << (self.n - 1)  # s 是当前要处理的位
        while s > 0:
            rx = (x & s) > 0
            ry = (y & s) > 0
            d += s * s * ((3 * rx) ^ ry)  # 计算当前子块的索引贡献
            if ry == 0:
                if rx == 1:
                    x, y = s - 1 - x, s - 1 - y
                # 交换 x 和 y
                x, y = y, x
            s //= 2
        return d


if __name__ == '__main__':
    print("时间测试---------H2P---------------")
    for i in range(1, 9):
        N = 128 * i
        hilbert = Hilbert(N)
        st = time.time()
        for _ in range(1000):
            d = hilbert.d2xy_down(1)
        en = time.time()
        print(f"Hilbert order N = {N}; total time {en - st} s")

    print("时间测试---------P2H---------------")
    for i in range(1, 9):
        N = 128 * i
        hilbert = Hilbert(N)
        x = random.randint(1, 4**N)
        y = random.randint(1, 4**N)
        st = time.time()
        for _ in range(1000):
            d = hilbert.xy2d_up(x, y)
        en = time.time()
        print(f"Hilbert order N = {N}; total time {en - st} s")
