import networkx as nx
import numpy as np
import osmnx as ox
from geopy.distance import geodesic

import tools

# G = ox.graph.graph_from_bbox(box, network_type="walk")
# print(f'{box_name}: node {G.number_of_nodes()}, edges {G.number_of_edges()}')
name = 'Seattle, USA'
type_ = 'walk'
G = ox.graph.graph_from_place(name, network_type=type_)
print(f'{name}: type {type_}, node {G.number_of_nodes()}, edges {G.number_of_edges()}')
