import networkx as nx
import numpy as np
import osmnx as ox
from geopy.distance import geodesic

import tools

print(ox.__version__)


def get_area(bbox):
    coord1 = (bbox[1], bbox[0])
    coord2 = (bbox[3], bbox[0])
    x = round(geodesic(coord1, coord2).meters, 0)
    coord1 = (bbox[3], bbox[2])
    y = round(geodesic(coord1, coord2).meters, 0)
    return x, y


# bboxBJ = (116.399827, 39.914378, 116.420972, 39.932243)
# bboxChicago = (-87.806309, 41.875329, -87.761148, 41.909412)
# bboxFC = (-75.185114, 39.916969, -75.154853, 39.940303)

box = (116.399827, 39.914378, 116.420972, 39.932243)
box_name = 'Beijing'

G = ox.graph.graph_from_bbox(box, network_type="walk")
print(f'{box_name}: node {G.number_of_nodes()}, edges {G.number_of_edges()}')
width, length = get_area(box)
print(f'Width and Length: {(width, length)}')

img_path = f'./datasets/{box_name}.png'
fig, ax = ox.plot.plot_graph(G, figsize=(20, 20), edge_color="w", edge_linewidth=4, save=True, filepath=img_path)

cell = 16
w_cells = int(width) // cell
l_cells = int(length) // cell

print("网格图生成中...")
matrix2 = tools.image_split(img_path, w_cells, l_cells, percent=0.01)
np.save(f'./datasets/{box_name}.npy', matrix2)

print("网格图绘制中...")
grid_path = f'./datasets/{box_name}_grid.png'
tools.plot_grid_road(matrix2, save=True, filepath=grid_path)

