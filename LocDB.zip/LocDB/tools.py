import cv2
import numpy as np
from matplotlib import pyplot as plt


def image_split(image_path: str, rows, cols, percent):
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    height, width = img.shape

    matrix2 = np.zeros((rows, cols), dtype=np.uint8)

    block_height = height // rows
    block_width = width // cols

    for i in range(rows):
        for j in range(cols):
            # 计算小图片的边界
            left = j * block_width
            upper = i * block_height
            right = left + block_width
            lower = upper + block_height

            # 裁剪小图片
            block = img[upper:lower, left:right]

            cnt = 0
            for row in block:
                for element in row:
                    if element > 128:
                        cnt += 1
            if cnt > percent * (block_width * block_height):
                matrix2[i, j] = 1

            # 保存小图片
            # cv2.imwrite(f"./{output_dir}/block_{i}_{j}.png", block)
    return matrix2


def plot_grid_road(mat2, save: bool, filepath: str):
    rows, cols = mat2.shape
    plt.figure(figsize=(cols * 0.3, rows * 0.3))

    for i in range(rows):
        for j in range(cols):
            if mat2[i, j] == 1:
                plt.fill_between([j, j+ 1], i, i + 1, facecolor='green', alpha=0.5)

    plt.xlim((0, cols))
    plt.ylim((rows, 0))

    plt.xticks(np.arange(0, cols, 1))
    plt.yticks(np.arange(0, rows, 1))
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.grid(True, linestyle='-', color='gray', alpha=0.7, zorder=0)
    plt.tight_layout()
    if save:
        plt.savefig(filepath)
        return
    plt.show()

